"""
AWS Lambda Scrapers Package

This empty __init__.py file is necessary for Python packaging to work properly.
It allows Python to recognize this directory as a package and import modules from it.
"""
